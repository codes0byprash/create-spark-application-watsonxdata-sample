import os
CONFIG = {
"API_KEY" : "1CejUfmTwjIDYR5K2lvuRd6T5C9Hks75Na6WkfiJ00-N", 
"INSTANCE_ROUTE" : "https://us-south.lakehouse.cloud.ibm.com",
"LH_INSTANCE_ID" : "crn:v1:bluemix:public:lakehouse:us-south:a/1d21420d9cd62a443e3d662cfc9c6a19:c6285b64-3d32-4762-8a36-db2d1e18dad3::",
"SPARK_ENGINE_ID" : "spark644",
"BUCKET_NAME" : "csi-catalog-bucket",
"WXD_USERNAME": "pbakhrel@crushbank.com",
"WXD_APIKEY" : "1CejUfmTwjIDYR5K2lvuRd6T5C9Hks75Na6WkfiJ00-N",
"COS_ENDPOINT" : "https://s3.us-south.cloud-object-storage.appdomain.cloud",
"COS_ACCESS_KEY":"6de1127078464ff6bb1c15935efd95c6",
"COS_SECRET_KEY":"0cf9f4f337ebf747934c71d2f7e4c24e6cbefd4e64faa847"
}

def get_config(key, required=False):
    value = CONFIG.get(key)
    if required and value is None:
        raise ValueError(f"Missing required config: {key}")
    return value